package net.whampx.bankingapp.service;

import net.whampx.bankingapp.dto.AccountDto;

public interface AccountService {
    AccountDto createAccount(AccountDto accountDto);
}
